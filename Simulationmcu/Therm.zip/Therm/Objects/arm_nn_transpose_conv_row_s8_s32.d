./objects/arm_nn_transpose_conv_row_s8_s32.o: \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Source\NNSupportFunctions\arm_nn_transpose_conv_row_s8_s32.c \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Include\arm_nnsupportfunctions.h \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Include\Internal\arm_nn_compiler.h \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Include\arm_nn_math_types.h \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Include\arm_nn_types.h
