./objects/arm_vector_sum_s8_s64.o: \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Source\FullyConnectedFunctions\arm_vector_sum_s8_s64.c \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Include\arm_nnfunctions.h \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Include\arm_nn_math_types.h \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Include\arm_nn_types.h \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Include\arm_nnsupportfunctions.h \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Include\Internal\arm_nn_compiler.h
