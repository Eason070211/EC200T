./objects/arm_depthwise_conv_s4_opt.o: \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Source\ConvolutionFunctions\arm_depthwise_conv_s4_opt.c \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Include\arm_nnfunctions.h \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Include\arm_nn_math_types.h \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Include\arm_nn_types.h \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Include\arm_nnsupportfunctions.h \
  D:\keil\pack\ARM\CMSIS-NN\7.0.0\Include\Internal\arm_nn_compiler.h
